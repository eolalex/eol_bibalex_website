function file_checked(){
	if( $('#file-upload').val() != "" ) {

alert($('#label_data'));

} 
  // var check_file = document.getElementById('file-upload');
 // alert (check_file);
  // alert("yes");
   // $(document).ready(function(){
    // $("input[type=file]").click(function(){
       // $(this).val("");
    // });
// 
    // $("input[type=file]").change(function(){
        // alert($(this).val());
    // });
// });
 }
;
