$(document).ready(function() {
  setTimeout(function(){
    $('.alert').slideUp(500);
  }, 3000);
    setTimeout(function(){
    $('.notice').slideUp(500);
  }, 3000);
    setTimeout(function(){
    $('.error').slideUp(500);
  }, 3000);
      setTimeout(function(){
    $('.success').slideUp(500);
  }, 3000);
    setTimeout(function(){
    $('.modal-backdrop.fade.in').slideUp(500);
  }, 3000);
});
