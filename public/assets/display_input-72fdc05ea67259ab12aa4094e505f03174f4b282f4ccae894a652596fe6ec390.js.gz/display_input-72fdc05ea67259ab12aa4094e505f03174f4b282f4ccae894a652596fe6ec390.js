function file_checked(){
	if( $('#file-upload').val() != "" ) {
$('#label_data').text($('#file-upload').val());

} 
 }
;
