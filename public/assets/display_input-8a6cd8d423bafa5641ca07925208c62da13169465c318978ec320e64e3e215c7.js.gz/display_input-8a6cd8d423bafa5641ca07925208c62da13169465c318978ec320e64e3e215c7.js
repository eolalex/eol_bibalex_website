function input_hide(){
 // var check_file = document.getElementById('file-upload').style.display = 'none';
 // alert (check_file);
 alert("yes");
  }
;
