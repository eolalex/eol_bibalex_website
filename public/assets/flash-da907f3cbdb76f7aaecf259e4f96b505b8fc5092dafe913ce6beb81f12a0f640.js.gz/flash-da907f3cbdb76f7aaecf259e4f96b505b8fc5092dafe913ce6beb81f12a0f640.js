$(document).ready(function() {
  setTimeout(function(){
    $('.alert').slideUp(50);
  }, 100);
    setTimeout(function(){
    $('.notice').slideUp(50);
  }, 100);
    setTimeout(function(){
    $('.error').slideUp(50);
  }, 100);
      setTimeout(function(){
    $('.success').slideUp(50);
  }, 100);
    setTimeout(function(){
    $('.modal-backdrop.fade.in').slideUp(50);
  }, 100);
});
