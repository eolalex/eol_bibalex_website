$(document).ready(function() {
  setTimeout(function(){
    $('.alert').slideUp(5);
  }, 10);
    setTimeout(function(){
    $('.notice').slideUp(5);
  }, 10);
    setTimeout(function(){
    $('.error').slideUp(5);
  }, 10);
      setTimeout(function(){
    $('.success').slideUp(5);
  }, 10);
    setTimeout(function(){
    $('.modal-backdrop.fade.in').slideUp(5);
  }, 10);
});
